# Índice da Documentação — Matemática Instrumental

Versão: 1.0  
Status: APROVADO  
Última atualização: 18/08/2026

## Objetivo
Este conjunto de documentos constitui a referência oficial para o desenvolvimento do portal **Matemática Instrumental — Professor Adriano Lima Teixeira**.

Em caso de conflito entre propostas antigas, conversas, mockups rejeitados e documentos marcados como **APROVADO**, prevalece a documentação aprovada mais recente.

## Documentos
1. `01-ESPECIFICACAO-GERAL.md` — objetivos, público, princípios e requisitos gerais.
2. `02-ARQUITETURA-DO-SITE.md` — páginas, seções e fluxos de navegação.
3. `03-DESIGN-SYSTEM.md` — identidade visual, paletas, cabeçalho, ícones e responsividade.
4. `04-MODELO-DE-CONTEUDO.md` — estrutura de turmas, materiais, vídeos, provas e oportunidades.
5. `05-REGRAS-DE-AUTOMACAO.md` — novidades, prazos e estados Novo/Atenção/Destaque.
6. `06-ARQUITETURA-TECNICA.md` — tecnologias, hospedagem, Drive, CMS e formulário.
7. `07-DECISOES-DO-PROJETO.md` — registro das principais decisões aprovadas.
8. `08-CHECKLIST-DE-ACEITE.md` — critérios de validação antes da publicação.

## Referências visuais oficiais
Manter na pasta de referências:
- logotipos oficiais;
- símbolo π;
- assinatura da marca;
- foto do professor;
- imagem com as três paletas oficiais;
- mockup aprovado da página inicial.

## Regra de trabalho
**Documentação primeiro, implementação depois.**

Qualquer alteração relevante deve seguir:
1. registrar a decisão;
2. atualizar o documento correspondente;
3. atualizar mockup, se houver impacto visual;
4. aprovar a nova versão;
5. somente então alterar o código.
