# Regras de Automação

Versão: 1.0  
Status: APROVADO  
Última atualização: 18/08/2026

## Estados
- **Novo** — conteúdo recente.
- **Atenção** — prazo ou ação relevante.
- **Destaque** — promoção editorial.

## Regra geral
Conteúdo com data objetiva terá permanência em Novidades calculada automaticamente.

Ao vencer, o conteúdo sai de Novidades, mas não é apagado.

## Inscrição
Concurso, vestibular, ENEM ou processo seletivo:
- permanecer até o dia seguinte ao fim das inscrições.

## Prova
- permanecer até o dia seguinte à data da prova.

## Trabalho
- permanecer até o dia seguinte à entrega.

## Aviso com validade
- permanecer até a data definida;
- permitir saída no próprio dia ou no dia seguinte.

## Conteúdo sem data crítica
Aplicar período padrão configurável, inicialmente 7 a 10 dias conforme o tipo.

## Destaque manual
Permitir ativação e data final manual.

## Sobrescrita
Toda automação poderá ser substituída manualmente.

## Mensagens relativas
Quando pertinente:
- encerra em X dias;
- encerra amanhã;
- prova amanhã;
- entrega amanhã.

## Apresentação
Preferir série/ano amplo nas novidades.

## Histórico
“Ver todas” poderá manter histórico separado do painel compacto.
