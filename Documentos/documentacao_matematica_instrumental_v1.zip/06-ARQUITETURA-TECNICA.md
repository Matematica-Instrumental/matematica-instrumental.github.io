# Arquitetura Técnica

Versão: 1.0  
Status: APROVADO PARA IMPLEMENTAÇÃO  
Última atualização: 18/08/2026

## Stack prevista
- Astro;
- HTML/CSS/JavaScript;
- Git;
- GitHub;
- GitHub Pages;
- Pages CMS;
- Google Drive;
- Google Forms;
- Google Apps Script opcional.

## ChatGPT
Pode ser usado para planejamento, código, revisão e documentação.
O site publicado não dependerá do ChatGPT nem de API da OpenAI.

## Hospedagem
Site estático, inicialmente no GitHub Pages.

## Arquivos pedagógicos
PDFs e materiais grandes ficam no Google Drive.
O site guarda metadados e links.

## Conteúdo
Evitar arquivo único gigante. Preferir coleções e arquivos independentes.

## CMS
Pages CMS será configurado após a primeira versão funcional.

## Formulário
Um único formulário:
- turma automática;
- nome;
- e-mail obrigatório;
- motivo;
- mensagem.

## Vídeos
Hospedados no provedor original, exibidos por miniatura e player incorporado.

## Privacidade
- sem dados privados de alunos no GitHub;
- sem senhas no repositório;
- sem chaves expostas;
- minimizar coleta de dados.

## Fluxo
1. documentação;
2. mockup;
3. implementação local;
4. revisão;
5. checklist;
6. commit;
7. publicação;
8. validação responsiva.
