# Checklist de Aceite

Versão: 1.0  
Status: APROVADO  
Última atualização: 18/08/2026

## Identidade
- [ ] Logo oficial correta.
- [ ] Foto oficial do professor quando prevista.
- [ ] Paletas respeitadas.
- [ ] Sem mistura arbitrária entre linhas.

## Layout
- [ ] Fundo e boxes claramente distintos.
- [ ] Fundo cinza coerente.
- [ ] Boxes com superfícies/degradês discretos.
- [ ] Menu abaixo do cabeçalho no desktop.
- [ ] Boa hierarquia visual.

## Ícones
- [ ] Mesma família.
- [ ] Profissionais.
- [ ] Legíveis no celular.

## Responsividade
- [ ] Desktop testado.
- [ ] Tablet testado.
- [ ] Celular testado.
- [ ] Componentes reorganizados quando necessário.

## Novidades
- [ ] Novo/Atenção/Destaque funcionando.
- [ ] Prazos automáticos corretos.
- [ ] Conteúdo vencido sai de Novidades sem ser apagado.
- [ ] Rolagem interna no desktop.
- [ ] Versões adaptadas para tablet/celular.

## Turmas
- [ ] Segmento → Ano/Série → Turma.
- [ ] Fundamental e Médio diferenciados.
- [ ] Nova turma não exige alterar páginas fixas.
- [ ] Anos anteriores arquiváveis.

## Conteúdo
- [ ] Filtros funcionando.
- [ ] Busca funcionando onde prevista.
- [ ] Links do Drive funcionando.

## Vídeos
- [ ] Miniatura correta.
- [ ] Modal responsivo.
- [ ] Tela cheia quando suportada.
- [ ] Alternativa para abrir no provedor.

## Provas e oportunidades
- [ ] Filtros corretos.
- [ ] Links oficiais corretos.
- [ ] Datas corretas.
- [ ] Regras de prazo funcionando.
- [ ] Uso de materiais de terceiros respeita direitos.

## Comunicação
- [ ] Turma automática.
- [ ] Nome obrigatório.
- [ ] E-mail obrigatório.
- [ ] Motivo obrigatório.
- [ ] Mensagem obrigatória.
- [ ] Nada publicado no site.
- [ ] Dados pessoais fora do GitHub.

## Imagens
- [ ] Licença compatível.
- [ ] Fonte/licença registrada quando necessário.
- [ ] Imagens otimizadas.

## Qualidade
- [ ] Sem links quebrados.
- [ ] Sem dados de teste.
- [ ] Sem credenciais no repositório.
- [ ] Comparação com mockup aprovado realizada.
- [ ] Documentação atualizada antes da aprovação.
