# Resumo de Alterações — Proposta v1.2

Data: 22/08/2026

Esta proposta registra as decisões tomadas durante a aprovação dos mockups da página de turma.

## Alterações principais
- mockups de desktop, tablet e celular passam a ser referências específicas da página de turma;
- tablet: referência de 834 px, menus 3 × 2 e 4 × 2, frase em três linhas, resumos em uma coluna e botão de contato à direita;
- celular: referência de 390 px, menus compactos, menu da turma visível no box de navegação, cards verticais e quebra controlada de “Ver cronograma completo”;
- a faixa final de comunicação não exibe a frase de identificação automática da turma; a turma automática permanece requisito do formulário;
- checklist ampliado para validar explicitamente os três mockups responsivos.

## Sem alteração funcional
Não houve alteração no modelo de conteúdo, regras de automação ou campos do formulário.
