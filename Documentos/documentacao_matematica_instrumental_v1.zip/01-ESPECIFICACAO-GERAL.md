# Especificação Geral do Portal

Versão: 1.0  
Status: APROVADO  
Última atualização: 18/08/2026

## Identidade
Nome: **Matemática Instrumental**  
Responsável: **Professor Adriano Lima Teixeira**

## Público
Estudantes do Ensino Fundamental — Anos Finais e Ensino Médio.

## Objetivo
Oferecer um portal educacional organizado, profissional e simples de manter para:
- atividades e listas;
- conteúdos para estudo;
- avisos;
- trabalhos;
- vídeos, podcasts, artigos, portais e sites;
- provas e resoluções;
- concursos, vestibulares, ENEM, processos seriados, olimpíadas e oportunidades;
- divulgação matemática;
- comunicação privada aluno → professor.

## Princípios
O portal deverá ser:
- profissional;
- atraente;
- intuitivo;
- funcional;
- responsivo;
- rápido;
- escalável;
- simples de manter;
- independente do ChatGPT em produção.

## Restrições
- sem cadastro de alunos;
- sem comentários públicos;
- arquivos pedagógicos no Google Drive;
- sem dependência de API da OpenAI;
- compatível com hospedagem gratuita.

## Manutenção
Deve ser possível criar, sem programação cotidiana:
- anos letivos;
- turmas;
- atividades;
- avisos;
- conteúdos;
- trabalhos;
- vídeos;
- provas resolvidas;
- oportunidades;
- curiosidades, personalidades, leituras e sites recomendados.

## Crescimento
A estrutura deve suportar muitos anos, dezenas de turmas e grande volume de conteúdos com filtros, busca e arquivamento.

## Imagens
Imagens externas só poderão ser usadas se forem:
- próprias;
- de domínio público; ou
- licenciadas para reprodução.

Quando aplicável, registrar autor, fonte, licença e URL da licença.

## Comunicação
Campos mínimos:
- turma automática;
- nome obrigatório;
- e-mail obrigatório;
- motivo obrigatório;
- mensagem obrigatória.

## Responsividade
Desktop, tablet e celular terão adaptações próprias de layout.
