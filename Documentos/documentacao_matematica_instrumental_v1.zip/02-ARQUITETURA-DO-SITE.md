# Arquitetura Organizacional do Site

Versão: 1.0  
Status: APROVADO  
Última atualização: 18/08/2026

## Início
- identidade visual no topo;
- foto do professor integrada ao cabeçalho;
- menu principal abaixo do cabeçalho;
- área de apresentação;
- painel de novidades;
- acesso rápido;
- acesso às turmas;
- destaques de Matemática além da sala;
- rodapé institucional.

## Turmas
Hierarquia obrigatória:

**Segmento → Ano/Série → Turma**

### Ensino Fundamental — Anos Finais
6º, 7º, 8º e 9º anos.

### Ensino Médio
1º, 2º e 3º anos.

Na página inicial, priorizar o ano/série, evitando excesso de especificidade por turma.

## Página da turma
- avisos;
- atividades e listas;
- conteúdos para estudo;
- trabalhos;
- materiais complementares;
- vídeos de apoio;
- links e recomendações;
- botão Falar com o professor.

Filtros serão obrigatórios conforme o volume de conteúdo.

## Provas e Resoluções
Abranger ENEM, vestibulares, concursos, processos seriados, olimpíadas e outras instituições.

Filtros:
- instituição;
- ano;
- tipo;
- fase;
- assunto;
- dificuldade, quando aplicável;
- busca.

## Oportunidades e Datas
- ENEM;
- vestibulares;
- CEFET/institutos;
- processos seriados;
- concursos;
- olimpíadas;
- eventos.

Filtros:
- categoria;
- instituição;
- segmento;
- situação;
- ano.

## Matemática além da sala
- Curiosidades;
- História da Matemática;
- Personalidades;
- Matemática no cotidiano;
- Aplicações;
- Desafios;
- Vídeos;
- Leituras;
- Sites e recursos.

## Novidades
### Desktop
Painel lateral compacto, altura controlada, rolagem interna e botão “Ver todas”.

### Tablet
Bloco compacto adaptado.

### Celular
Versão reduzida/compacta, podendo usar expansão ou rolagem horizontal.

As novidades devem privilegiar categorias amplas, como “3º ano”, e não “3º Ano A”.

## Menu principal
- Início
- Turmas
- Provas e Resoluções
- Oportunidades e Datas
- Matemática além da sala
- Falar com o Professor

## Acesso rápido
Boxes visualmente uniformes; não usar uma cor forte diferente para cada box.

## Acesso às turmas
Diferenciação cromática por segmento é desejada:
- Fundamental — Anos Finais;
- Ensino Médio.
