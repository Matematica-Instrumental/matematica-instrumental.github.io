# Design System — Matemática Instrumental

Versão: 1.0  
Status: APROVADO  
Última atualização: 18/08/2026

## Direção visual
Profissional, contemporânea, organizada, sóbria, amigável e não infantil.

## Cabeçalho
- cabeçalho maior;
- identidade visual em destaque;
- logo com forte presença horizontal;
- foto do professor ao lado do nome/identidade;
- menu abaixo do cabeçalho;
- menu ocupando a largura disponível no desktop.

## Fundo e seções
- fundo geral cinza;
- boxes claramente diferenciados;
- degradês discretos para mais claro ou mais escuro;
- evitar fundo e boxes com mesma aparência.

## Acesso rápido
Visual uniforme, sem uma cor forte distinta por opção.

## Segmentos
Fundamental e Médio podem usar cores diferentes, de forma elegante e coerente.

## Paletas oficiais

### Linha 1
`#2484BF` `#41CAD9` `#F2C335` `#D9B036` `#0D0D0D`

### Linha 2
`#3557F2` `#0320A6` `#F2C335` `#FFD452` `#A68114`

### Linha 3
`#3585A6` `#41BEF2` `#F2C335` `#4814A6` `#7229F2`

**Regra:** cada linha é um conjunto cromático próprio. Não misturar arbitrariamente cores de linhas diferentes.

## Ícones
- uma única família visual;
- profissionais;
- coerentes;
- preferencialmente SVG;
- estilo outline limpo e contemporâneo;
- evitar mistura de outline, preenchido, 3D e emojis.

## Estados visuais
- Novo
- Atenção
- Destaque

Preferir selos e ícones consistentes.

## Imagens
Somente próprias ou com direito de reprodução compatível.

## Vídeos
- miniatura 16:9;
- título;
- descrição breve;
- prioridade, quando aplicável;
- player em modal responsivo;
- tela cheia quando suportada;
- carregar iframe somente após interação, quando possível.

## Responsividade
Desktop, tablet e celular devem reorganizar componentes, e não apenas reduzi-los.

## Referência visual
O mockup aprovado da página inicial é referência obrigatória até nova aprovação.
