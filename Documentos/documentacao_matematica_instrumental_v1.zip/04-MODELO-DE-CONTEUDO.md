# Modelo de Conteúdo

Versão: 1.0  
Status: APROVADO  
Última atualização: 18/08/2026

## Princípio
Evitar um único arquivo gigante. Usar registros independentes e reutilizáveis.

## Turma
Campos:
- id;
- nome;
- slug;
- segmento;
- ano/série;
- turma;
- ano letivo;
- descrição;
- ativa/inativa;
- ordem.

## Atividade / Lista
- título;
- descrição;
- assunto;
- segmento;
- ano/série;
- turma(s);
- publicação;
- prazo;
- link do Google Drive;
- vídeos relacionados;
- tags;
- exibir em novidades?;
- tipo de novidade;
- data final automática/manual.

## Conteúdo para estudo
- título;
- resumo;
- assunto;
- segmento;
- ano/série;
- turma(s);
- link;
- vídeos relacionados;
- leituras relacionadas;
- tags;
- publicação.

## Trabalho
- título;
- descrição;
- orientações;
- segmento;
- ano/série;
- turma(s);
- publicação;
- entrega;
- link;
- tags.

## Aviso
- título;
- texto;
- público;
- segmento;
- ano/série;
- turma(s);
- publicação;
- validade;
- prioridade.

## Vídeo
Biblioteca reutilizável:
- id;
- título;
- URL;
- provedor;
- descrição;
- assunto;
- segmento;
- ano/série;
- prioridade: Essencial / Recomendado / Complementar;
- tags;
- duração;
- ativo/inativo.

## Prova / Resolução
- instituição;
- tipo;
- ano;
- fase;
- área/assunto;
- segmento;
- link da prova oficial;
- link da resolução;
- descrição;
- tags;
- dificuldade.

## Oportunidade / Data
- título;
- instituição;
- categoria;
- público;
- início de inscrições;
- fim de inscrições;
- data(s) de prova;
- link oficial;
- descrição;
- situação calculada;
- novidade.

## Curiosidade / Divulgação
- título;
- resumo;
- categoria;
- texto;
- imagem;
- licença da imagem;
- vídeo;
- links;
- tags;
- publicação.

## Site ou recurso externo
- nome;
- descrição;
- URL;
- segmento;
- finalidade;
- tipo;
- gratuito/pago, quando relevante;
- observação do professor.

## Filtros
Prever conforme a área:
- segmento;
- ano/série;
- turma;
- assunto;
- tipo;
- instituição;
- fase;
- ano;
- categoria;
- prioridade;
- tags;
- busca;
- ordenação por data.

## Arquivamento
Conteúdo antigo pode sair de destaques/novidades sem ser apagado.
