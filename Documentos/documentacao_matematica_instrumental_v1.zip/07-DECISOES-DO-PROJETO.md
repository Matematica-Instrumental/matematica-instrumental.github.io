# Registro de Decisões do Projeto

Versão: 1.0  
Status: APROVADO  
Última atualização: 18/08/2026

- DEC-001 — Site independente do ChatGPT.
- DEC-002 — Hospedagem gratuita.
- DEC-003 — Arquivos pedagógicos no Google Drive.
- DEC-004 — Sem cadastro de alunos.
- DEC-005 — Organização por Segmento → Ano/Série → Turma.
- DEC-006 — Suporte a anos letivos e arquivamento.
- DEC-007 — Filtros obrigatórios.
- DEC-008 — Biblioteca de vídeos reutilizável.
- DEC-009 — Vídeos com miniatura e player em modal.
- DEC-010 — Comunicação privada, sem comentários públicos.
- DEC-011 — E-mail obrigatório no formulário.
- DEC-012 — Turma automática no formulário.
- DEC-013 — Conteúdo global não deve ser duplicado por turma.
- DEC-014 — Usar “Personalidades”.
- DEC-015 — Área própria de Provas e Resoluções.
- DEC-016 — Novidades: Novo, Atenção e Destaque.
- DEC-017 — Prazos automáticos.
- DEC-018 — Novidades com painel lateral no desktop e layouts adaptados nos demais dispositivos.
- DEC-019 — Cabeçalho grande com identidade e foto do professor.
- DEC-020 — Menu abaixo do cabeçalho.
- DEC-021 — Fundo cinza e boxes diferenciados.
- DEC-022 — Acesso rápido uniforme.
- DEC-023 — Segmentos com distinção cromática.
- DEC-024 — Três linhas de paletas oficiais respeitadas separadamente.
- DEC-025 — Sistema único de ícones profissionais.
- DEC-026 — Somente imagens com direito de reprodução compatível.
- DEC-027 — Astro + GitHub + GitHub Pages + Pages CMS + Drive + Forms.
- DEC-028 — Mockup aprovado da home é a referência visual oficial.
