# Instrução sugerida para o Projeto no ChatGPT

Este Projeto desenvolve o portal Matemática Instrumental — Professor Adriano Lima Teixeira.

Os arquivos adicionados às Fontes do Projeto e marcados como APROVADO constituem a fonte oficial de requisitos.

Em caso de conflito entre conversa antiga, proposta, mockup rejeitado e documento APROVADO, prevalece sempre o documento APROVADO mais recente.

Nenhuma implementação deve alterar requisito aprovado sem atualizar primeiro a documentação correspondente.

Antes de implementar qualquer funcionalidade:
1. consulte `00-INDICE.md`;
2. consulte `01-ESPECIFICACAO-GERAL.md`;
3. consulte os documentos específicos relacionados;
4. consulte o mockup aprovado quando houver impacto visual;
5. use `08-CHECKLIST-DE-ACEITE.md` antes de considerar a implementação concluída.

O ChatGPT é ferramenta de desenvolvimento e revisão. O site publicado deve permanecer independente do ChatGPT.
