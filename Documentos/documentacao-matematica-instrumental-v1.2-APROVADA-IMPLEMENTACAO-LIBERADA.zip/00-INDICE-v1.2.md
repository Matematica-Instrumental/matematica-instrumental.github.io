# Índice da Documentação — Matemática Instrumental

Versão: 1.2  
Status: APROVADO
Última atualização: 22/08/2026

## Objetivo
Este conjunto de documentos constitui a referência oficial para o desenvolvimento do portal **Matemática Instrumental — Professor Adriano Lima Teixeira**.

Em caso de conflito entre propostas antigas, conversas, mockups rejeitados e documentos marcados como **APROVADO**, prevalece a documentação aprovada mais recente.

## Documentos
1. `01-ESPECIFICACAO-GERAL-v1.2.md` — objetivos, público, princípios e requisitos gerais.
2. `02-ARQUITETURA-DO-SITE-v1.2.md` — páginas, seções, fluxos de navegação e estrutura da página de turma.
3. `03-DESIGN-SYSTEM-v1.2.md` — identidade visual, paletas, cabeçalho, menus, ícones e responsividade.
4. `04-MODELO-DE-CONTEUDO-v1.2.md` — estrutura de turmas, cronogramas, atividades, estudos, trabalhos, materiais, vídeos e demais conteúdos.
5. `05-REGRAS-DE-AUTOMACAO-v1.2.md` — Novidades, prazos, estados automáticos e regras temporais.
6. `06-ARQUITETURA-TECNICA-v1.2.md` — tecnologias, hospedagem, Drive, CMS, formulário e regras de edição/publicação.
7. `07-DECISOES-DO-PROJETO-v1.2.md` — registro das principais decisões aprovadas.
8. `08-CHECKLIST-DE-ACEITE-v1.2.md` — critérios de validação antes da publicação.
9. `09-MOCKUPS-APROVADOS-v1.2.md` — referências visuais aprovadas de desktop, tablet e celular para a página de turma.

## Referências visuais oficiais
Manter na pasta de referências:
- logotipos oficiais;
- símbolo π;
- assinatura da marca;
- foto do professor;
- imagem com as três paletas oficiais;
- mockup aprovado da página inicial.

## Situação da página de turma
Os mockups específicos de **desktop, tablet e celular** foram elaborados e aprovados.

As condições prévias para implementação foram cumpridas:
1. documentação v1.2 aprovada;
2. mockups de desktop, tablet e celular aprovados;
3. ETAPA 23 — checklist pré-implementação aprovada;
4. ETAPA 24 — liberação formal para implementação aprovada em 22/08/2026.

**Situação atual: IMPLEMENTAÇÃO LIBERADA.**

As referências visuais consolidadas estão registradas em `09-MOCKUPS-APROVADOS-v1.2.md`. O checklist integral continuará obrigatório após a implementação e antes da publicação.

## Registros de liberação
- `ETAPA-23-CHECKLIST-PRE-IMPLEMENTACAO-v1.2.md` — auditoria pré-implementação aprovada.
- `ETAPA-24-LIBERACAO-PARA-IMPLEMENTACAO-v1.2.md` — registro formal da liberação da implementação.

## Regra de trabalho
**Documentação primeiro, mockup depois, implementação por último.**

Qualquer alteração relevante deve seguir:
1. registrar a decisão;
2. atualizar o documento correspondente;
3. atualizar ou criar mockup, se houver impacto visual;
4. aprovar a nova versão;
5. somente então alterar o código.
